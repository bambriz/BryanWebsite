This page has moved!<br>
Please update your link to point [here](https://github.com/facebookincubator/create-react-app/blob/master/packages/react-scripts/template/README.md) instead.

Sorry for the inconvenience!
